# PortableApps.com Installer

This is a fork of the [PortableApps.com Installer](https://portableapps.com/apps/development/portableapps.com_installer). I took the InstallerWizard.nsi and removed most if not all of the UI components to create a silent installer that can be used build automation.

## Compiling

```code
.\App\nsis\makensis.exe .\Other\Source\InstallerSilent.nsi
```

This creates a PortableApps.comSilentInstaller.exe. This application does not create the final portable application installer. It preps the application's work folder.

```code
.\PortableApps.comSilentInstaller.exe  "C:\Users\franc\GitHub\SABnzbdPortable\SABnzbdPortable"
```

The installer is built by using *makensis* directly.

```code
.\App\nsis\makensis.exe "C:\Users\franc\GitHub\SABnzbdPortable\SABnzbdPortable\Other\Source\PortableApps.comInstaller.nsi"
```
