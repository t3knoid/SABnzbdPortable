//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by inetc.rc
//
#define IDC_SLOGIN                      8
#define IDC_PROGRESS                    10
#define IDC_SUBTEXT                     11
#define IDC_SPWD                        11
#define IDC_ICON1                       12
#define IDD_DIALOG1                     101
#define IDI_ICON1                       102
#define IDI_ICON2                       103
#define IDD_AUTH                        104
#define IDI_ICON3                       105
#define IDI_ICON4                       106
#define IDI_ICON5                       107
#define IDD_DIALOG2                     108
#define IDI_ICON6                       109
#define IDD_DIALOG3                     110
#define IDC_STATIC1                     1001
#define IDC_STATIC2                     1002
#define IDC_STATIC3                     1003
#define IDC_STATIC4                     1004
#define IDC_PROGRESS1                   1005
#define IDC_STATIC5                     1006
#define IDC_STATIC6                     1007
#define IDC_STATIC12                    1008
#define IDC_STATIC13                    1009
#define IDC_STATIC20                    1009
#define IDC_STATIC21                    1010
#define IDC_STATIC22                    1011
#define IDC_STATIC23                    1012
#define IDC_STATIC24                    1013
#define IDC_STATIC25                    1014
#define IDC_ELOGIN                      1015
#define IDC_EPWD                        1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
