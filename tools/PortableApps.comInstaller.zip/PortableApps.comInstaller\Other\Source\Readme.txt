PortableApps.com Installer
==========================
Copyright 2006-2009 John T. Haller

Website: http://PortableApps.com/Installer

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


About PortableApps.com Installer
================================
PortableApps.com Installer allows you to easily package apps in PortableApps.com
Format as a PortableApps.com Installer.


LICENSE
=======
This code is released under the GPL.  Within the Other\Source directory
you will find the code as well as the full GPL license (License.txt).  If you use the
code in your own product, please give proper and prominent attribution.


PortableApps.com Installer CONFIGURATION
========================================
Configuration options are included in the appropriate appinfo.ini and installer.ini
files in the app's AppInfo directory as detailed at PortableApps.com/development