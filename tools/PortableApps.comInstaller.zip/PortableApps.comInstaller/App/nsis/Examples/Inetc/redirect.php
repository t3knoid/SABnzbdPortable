<?php
/* 
   Location header sets 302 status
*/
header("Location: http://localhost/index.htm")
?>
